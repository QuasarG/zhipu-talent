#!/usr/bin/env python3
"""
简历文本提取工具

支持格式：
  - PDF  (.pdf)   — 使用 pdfplumber 提取
  - Word (.docx)  — 使用 python-docx 提取
  - 纯文本 (.txt) — 直接读取

用法：
  # 提取单个文件
  python extract_resume.py --input /path/to/resume.pdf
  python extract_resume.py --input /path/to/resume.docx
  python extract_resume.py --input /path/to/resume.txt

  # 提取并保存到文件
  python extract_resume.py --input /path/to/resume.pdf --output /path/to/output.txt

  # 批量提取目录下所有简历
  python extract_resume.py --batch /path/to/resume_dir/

依赖：
  pip install pdfplumber python-docx
"""

import argparse
import os
import sys
import glob
from pathlib import Path


# ── 提取核心逻辑 ──────────────────────────────────────────────────────────


def extract_pdf(file_path: str) -> str:
    """使用 pdfplumber 提取 PDF 文本。"""
    import pdfplumber

    pages_text = []
    with pdfplumber.open(file_path) as pdf:
        for i, page in enumerate(pdf.pages, 1):
            text = page.extract_text()
            if text:
                pages_text.append(f"[第{i}页]\n{text.strip()}")
    if not pages_text:
        return ""
    return "\n\n".join(pages_text)


def extract_docx(file_path: str) -> str:
    """使用 python-docx 提取 Word 文档文本。"""
    from docx import Document

    doc = Document(file_path)
    paragraphs = []
    for para in doc.paragraphs:
        text = para.text.strip()
        if text:
            paragraphs.append(text)

    # 也提取表格中的内容
    for table in doc.tables:
        for row in table.rows:
            cells = [cell.text.strip() for cell in row.cells if cell.text.strip()]
            if cells:
                paragraphs.append(" | ".join(cells))

    return "\n".join(paragraphs)


def extract_text(file_path: str) -> str:
    """直接读取纯文本文件（UTF-8 自动探测编码）。"""
    encodings = ["utf-8", "gbk", "gb2312", "utf-16", "latin-1"]
    for enc in encodings:
        try:
            with open(file_path, "r", encoding=enc) as f:
                return f.read().strip()
        except (UnicodeDecodeError, UnicodeError):
            continue
    # 兜底：用 latin-1（不会抛异常，但中文可能乱码）
    with open(file_path, "r", encoding="latin-1") as f:
        return f.read().strip()


# ── 文本后处理 ────────────────────────────────────────────────────────────


def clean_text(text: str) -> str:
    """清理提取后的文本：去多余空行、去首尾空格。"""
    if not text:
        return text
    lines = text.splitlines()
    cleaned = []
    for line in lines:
        stripped = line.strip()
        if stripped:
            cleaned.append(stripped)
        elif cleaned and cleaned[-1] != "":
            cleaned.append("")
    # 去除末尾连续空行
    while cleaned and cleaned[-1] == "":
        cleaned.pop()
    return "\n".join(cleaned)


# ── 文件发现 ──────────────────────────────────────────────────────────────


SUPPORTED_EXTENSIONS = {".pdf", ".docx", ".txt"}


def find_resume_files(path: str) -> list[str]:
    """递归查找目录下所有支持的简历文件。"""
    path = os.path.abspath(path)
    files = []
    for ext in SUPPORTED_EXTENSIONS:
        files.extend(glob.glob(os.path.join(path, "**", f"*{ext}"), recursive=True))
    # 按文件名排序
    files.sort()
    return files


# ── 主调度 ────────────────────────────────────────────────────────────────


def extract(file_path: str) -> str:
    """根据文件扩展名自动选择提取方式。"""
    ext = Path(file_path).suffix.lower()
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"文件不存在: {file_path}")

    if ext == ".pdf":
        text = extract_pdf(file_path)
    elif ext == ".docx":
        text = extract_docx(file_path)
    elif ext == ".txt":
        text = extract_text(file_path)
    else:
        raise ValueError(
            f"不支持的文件格式: {ext}，支持: {', '.join(sorted(SUPPORTED_EXTENSIONS))}"
        )

    return clean_text(text)


def run_single(input_path: str, output_path: str | None = None) -> None:
    """处理单个文件。"""
    print(f"📄 正在提取: {input_path}", file=sys.stderr)
    try:
        text = extract(input_path)
    except Exception as e:
        print(f"❌ 提取失败: {e}", file=sys.stderr)
        sys.exit(1)

    if not text:
        print("⚠️  提取结果为空（PDF 可能是扫描件，建议先用 OCR 处理）", file=sys.stderr)
        sys.exit(1)

    char_count = len(text)
    line_count = text.count("\n") + 1
    print(f"✅ 提取完成：{char_count} 字符，{line_count} 行\n", file=sys.stderr)

    if output_path:
        os.makedirs(os.path.dirname(os.path.abspath(output_path)) or ".", exist_ok=True)
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(text)
        print(f"💾 已保存到: {output_path}", file=sys.stderr)
    else:
        # 输出到 stdout，供 pipeline 使用
        sys.stdout.write(text)


def run_batch(batch_dir: str) -> None:
        """批量处理目录下所有简历。"""
        batch_dir = os.path.abspath(batch_dir)
        if not os.path.isdir(batch_dir):
            print(f"❌ 目录不存在: {batch_dir}", file=sys.stderr)
            sys.exit(1)

        files = find_resume_files(batch_dir)
        if not files:
            print(f"⚠️  在目录中未找到支持的简历文件: {batch_dir}", file=sys.stderr)
            print(f"   支持的格式: {', '.join(sorted(SUPPORTED_EXTENSIONS))}", file=sys.stderr)
            sys.exit(0)

        output_dir = os.path.join(batch_dir, "_extracted")
        os.makedirs(output_dir, exist_ok=True)

        success = 0
        fail = 0
        for fp in files:
            rel = os.path.relpath(fp, batch_dir)
            out_name = Path(fp).stem + ".txt"
            out_path = os.path.join(output_dir, out_name)
            print(f"  [{Path(fp).suffix[1:].upper():>4}] {rel}", file=sys.stderr)
            try:
                text = extract(fp)
                if text:
                    with open(out_path, "w", encoding="utf-8") as f:
                        f.write(text)
                    success += 1
                else:
                    print(f"         ⚠️  空内容", file=sys.stderr)
                    fail += 1
            except Exception as e:
                print(f"         ❌ {e}", file=sys.stderr)
                fail += 1

        print(f"\n{'='*40}", file=sys.stderr)
        print(f"批量提取完成：成功 {success} 个，失败 {fail} 个", file=sys.stderr)
        print(f"提取结果保存在: {output_dir}", file=sys.stderr)


# ── CLI ───────────────────────────────────────────────────────────────────


def main():
    parser = argparse.ArgumentParser(
        description="简历文本提取工具 — 从 PDF / Word / 纯文本中提取文字内容",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )

    parser.add_argument(
        "--input", "-i",
        metavar="FILE",
        help="输入简历文件路径（支持 .pdf / .docx / .txt）"
    )
    parser.add_argument(
        "--batch", "-b",
        metavar="DIR",
        help="批量处理目录下的所有简历文件"
    )
    parser.add_argument(
        "--output", "-o",
        metavar="FILE",
        help="输出文件路径（不指定则输出到 stdout）"
    )
    parser.add_argument(
        "--list-formats", "-l",
        action="store_true",
        help="列出支持的文件格式后退出"
    )

    args = parser.parse_args()

    if args.list_formats:
        print("支持的文件格式:")
        for ext in sorted(SUPPORTED_EXTENSIONS):
            if ext == ".pdf":
                print(f"  {ext:8s} PDF (pdfplumber)")
            elif ext == ".docx":
                print(f"  {ext:8s} Word (python-docx)")
            elif ext == ".txt":
                print(f"  {ext:8s} 纯文本")
        return

    if args.batch:
        run_batch(args.batch)
    elif args.input:
        run_single(args.input, args.output)
    else:
        parser.print_help()
        print("\n错误: 请指定 --input 或 --batch 参数", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
