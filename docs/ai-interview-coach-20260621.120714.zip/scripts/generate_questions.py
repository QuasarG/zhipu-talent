#!/usr/bin/env python3
"""
面试题生成工具 — 从简历中提取内容，按技术栈、项目经验、工作年限
自动生成针对性的面试题目。

用法：
  # 从简历文件生成面试题（默认输出 markdown）
  python generate_questions.py --input /path/to/resume.pdf

  # 从简历文本直接生成
  python generate_questions.py --text "姓名：张三..."

  # 指定目标岗位和题目数量（可精确匹配 AI 岗位）
  python generate_questions.py --input resume.pdf --role "NLP算法工程师" --count 10

  # 按 AI 岗位能力模型出题（加载 ai-jobs/ 参考文件中的 L1/L2/L3 分级）
  python generate_questions.py --input resume.pdf --ai-role AI研发工程师

  # 加载 ai-jobs-questions 题库参考文件
  python generate_questions.py --input resume.pdf --ai-role AI研发工程师 --with-bank
  python generate_questions.py --input resume.pdf --ai-role AI数据治理工程师
  python generate_questions.py --input resume.pdf --ai-role AI测试工程师
  python generate_questions.py --input resume.pdf --ai-role AI安全工程师
  python generate_questions.py --input resume.pdf --ai-role AI产品经理

  # 只出技术题，保存到文件
  python generate_questions.py --input resume.pdf --type tech --output questions.md

  # JSON 格式输出（供其他工具消费）
  python generate_questions.py --input resume.pdf --format json

  # 指定候选人级别，覆盖自动检测
  python generate_questions.py --input resume.pdf --level senior

依赖：
  pip install pdfplumber python-docx
"""

import argparse
import json
import os
import re
import sys
from pathlib import Path

# AI 岗位参考文件路径
SKILL_DIR = Path(__file__).resolve().parent.parent
AI_JOBS_DIR = SKILL_DIR / "references" / "ai-jobs"
AI_QUESTIONS_DIR = SKILL_DIR / "references" / "ai-jobs-questions"
LLM_QUESTIONS_DIR = SKILL_DIR / "references" / "llm-questions"
AI_JOB_ROLES = {
    "AI研发工程师": AI_JOBS_DIR / "AI研发工程师.md",
    "AI数据治理工程师": AI_JOBS_DIR / "AI数据治理工程师.md",
    "AI测试工程师": AI_JOBS_DIR / "AI测试工程师.md",
    "AI安全工程师": AI_JOBS_DIR / "AI安全工程师.md",
    "AI产品经理": AI_JOBS_DIR / "AI产品经理.md",
}

# LLM 通用面试题题目文件
LLM_TOPICS = {
    "词向量基础": LLM_QUESTIONS_DIR / "词向量与语言模型基础.md",
    "大模型原理": LLM_QUESTIONS_DIR / "大模型原理与架构.md",
    "提示工程": LLM_QUESTIONS_DIR / "大模型使用与提示工程.md",
    "微调对齐": LLM_QUESTIONS_DIR / "大模型微调与对齐.md",
    "推理部署": LLM_QUESTIONS_DIR / "推理与部署.md",
    "RAG": LLM_QUESTIONS_DIR / "RAG技术与应用.md",
    "Agent": LLM_QUESTIONS_DIR / "Agent智能体.md",
    "VLM多模态": LLM_QUESTIONS_DIR / "VLM与多模态.md",
    "AI工具": LLM_QUESTIONS_DIR / "AI工具与Skills.md",
}


# ══════════════════════════════════════════════════════════════════════════
#  简历内容提取（复用 extract_resume.py 的逻辑）
# ══════════════════════════════════════════════════════════════════════════

def extract_text_from_file(file_path: str) -> str:
    """根据文件扩展名自动提取文本。"""
    ext = Path(file_path).suffix.lower()

    if not os.path.exists(file_path):
        raise FileNotFoundError(f"文件不存在: {file_path}")

    if ext == ".pdf":
        import pdfplumber
        pages = []
        with pdfplumber.open(file_path) as pdf:
            for i, page in enumerate(pdf.pages, 1):
                text = page.extract_text()
                if text:
                    pages.append(f"[第{i}页]\n{text.strip()}")
        return "\n\n".join(pages)

    elif ext == ".docx":
        from docx import Document
        doc = Document(file_path)
        paragraphs = []
        for para in doc.paragraphs:
            t = para.text.strip()
            if t:
                paragraphs.append(t)
        for table in doc.tables:
            for row in table.rows:
                cells = [c.text.strip() for c in row.cells if c.text.strip()]
                if cells:
                    paragraphs.append(" | ".join(cells))
        return "\n".join(paragraphs)

    elif ext == ".txt":
        for enc in ["utf-8", "gbk", "gb2312", "utf-16"]:
            try:
                with open(file_path, "r", encoding=enc) as f:
                    return f.read().strip()
            except (UnicodeDecodeError, UnicodeError):
                continue
        with open(file_path, "r", encoding="latin-1") as f:
            return f.read().strip()

    else:
        raise ValueError(f"不支持的文件格式: {ext}，支持: .pdf .docx .txt")


# ══════════════════════════════════════════════════════════════════════════
#  简历解析
# ══════════════════════════════════════════════════════════════════════════

RESUME_SECTION_KEYWORDS = {
    "个人信息": ["姓名", "电话", "邮箱", "个人信息", "联系方式"],
    "教育背景": ["教育", "学校", "大学", "学院", "学历", "学位", "硕士", "博士", "本科", "专业"],
    "工作经历": ["工作", "经历", "公司", "任职", "就职", "在职"],
    "项目经历": ["项目", "项目经验"],
    "技能": ["技能", "技术栈", "熟练掌握", "熟悉", "精通", "编程语言"],
    "证书奖项": ["证书", "奖项", "荣誉", "获奖", "竞赛", "奖"],
    "自我评价": ["自我评价", "个人评价", "关于我", "个人简介"],
}

# 常见技术关键词 → 技术领域映射
TECH_DOMAIN_KEYWORDS = {
    "大模型": ["大模型", "LLM", "DeepSeek", "Qwen",
               "Baichuan", "GLM", "ChatGLM", "百川", "千问"],
    "NLP": ["NLP", "自然语言", "BERT", "Transformer", "文本分类", "命名实体", "关系抽取",
            "情感分析", "分词", "词向量", "Word2Vec", "seq2seq", "Attention"],
    "CV": ["CV", "计算机视觉", "图像分类", "目标检测", "图像分割", "OCR", "人脸",
           "YOLO", "CNN"],
    "Agent": ["Agent", "智能体", "Multi-Agent", "LangGraph", "CrewAI",
              "function calling", "tool use", "ReAct"],
    "RAG": ["RAG", "检索增强", "向量数据库", "Embedding", "语义检索", "混合检索",
            "Hybrid Search", "Reranker", "重排", "语义分块", "Chunking"],
    "推荐系统": ["推荐", "召回", "排序", "协同过滤", "CTR", "DeepFM", "DIN", "多目标"],
    "大数据": ["Spark", "Flink", "Hadoop", "Hive", "Kafka", "HBase", "数据仓库", "ETL",
              "MapReduce", "Storm"],
    "后端开发": ["Spring", "Django", "FastAPI", "Flask", "微服务", "RESTful", "gRPC",
                "MySQL", "PostgreSQL", "Redis", "MongoDB", "Docker", "K8s"],
    "前端开发": ["React", "Vue", "Angular", "JavaScript", "TypeScript", "HTML", "CSS",
                "Webpack", "Vite"],
    "MLOps": ["MLOps", "模型部署", "模型服务", "vLLM", "TensorRT", "ONNX", "模型压缩",
              "量化", "蒸馏", "CI/CD", "Kubeflow"],
    "数据分析": ["数据分析", "可视化", "Tableau", "PowerBI", "A/B测试", "统计分析",
                "Python", "Pandas", "NumPy"],
    "安全": ["安全", "渗透", "漏洞", "CTF", "密码学", "Web安全", "网络安全"],
    "嵌入式": ["嵌入式", "RTOS", "MCU", "FPGA", "Linux驱动", "物联网", "IoT"],
    "测试": ["测试", "自动化测试", "性能测试", "Selenium", "pytest", "JUnit"],
}


def detect_experience_level(text: str) -> dict:
    """检测候选人经验级别。"""
    info = {"years": None, "level": "unknown", "is_fresh": False, "is_senior": False}

    # 提取工作年限
    patterns = [
        r"(\d+)\s*年.*?经验",
        r"工作.*?(\d+)\s*年",
        r"经验.*?(\d+)\s*年",
        r"(\d+)\s*年.*?开发",
        r"工龄[：:]\s*(\d+)",
    ]
    for p in patterns:
        m = re.search(p, text)
        if m:
            info["years"] = int(m.group(1))
            break

    # 检测应届生
    if re.search(r"应届|20\d{2}\s*年\s*毕业|即将.*?毕业", text):
        info["is_fresh"] = True
        if info["years"] is None:
            info["years"] = 0

    # 检测高级
    if info["years"] is not None and info["years"] >= 5:
        info["is_senior"] = True

    # 定级
    if info["is_fresh"] or (info["years"] is not None and info["years"] <= 1):
        info["level"] = "junior"
    elif info["years"] is not None and 1 < info["years"] <= 3:
        info["level"] = "mid"
    elif info["years"] is not None and 3 < info["years"] <= 5:
        info["level"] = "mid-senior"
    elif info["years"] is not None and info["years"] > 5:
        info["level"] = "senior"

    return info


def extract_skills(text: str) -> list[dict]:
    """提取技能列表及熟练度识别。"""
    skills = []

    # 按行扫描技能相关区域
    lines = text.splitlines()
    in_skill_section = False
    skill_lines = []

    for line in lines:
        stripped = line.strip()
        # 检测技能区域标题
        if any(kw in stripped for kw in ["技能", "技术栈", "核心技能"]):
            in_skill_section = True
            continue
        # 检测离开技能区域（遇到其他大标题）
        if in_skill_section and any(
            kw in stripped for kw in ["教育", "工作", "项目", "证书", "自我评价", "个人信息"]
        ) and len(stripped) < 15:
            in_skill_section = False
            continue
        if in_skill_section and stripped:
            skill_lines.append(stripped)

    # 如果没检测到技能区域，在全文中找技能关键词
    if not skill_lines:
        for line in lines:
            if any(kw in line for kw in ["精通", "熟悉", "掌握", "了解", "熟练"]):
                skill_lines.append(line.strip())

    # 解析每个技能行
    for line in skill_lines:
        # 尝试提取熟练度标记
        level = None
        if re.search(r"精通|proficient|expert", line, re.I):
            level = "expert"
        elif re.search(r"熟悉|skilled|strong", line, re.I):
            level = "strong"
        elif re.search(r"掌握|了解|knowledge|basic|familiar", line, re.I):
            level = "basic"

        # 提取具体技能名词
        found_skills = re.findall(r'[A-Za-z#+.+\-]+(?:\s*\([^)]+\))?', line)
        for s in found_skills:
            s = s.strip(" ,;.()（）")
            if len(s) >= 2 and not s.startswith("http"):
                skills.append({
                    "name": s,
                    "level": level or "mentioned",
                    "context": line[:80],
                })

    # 去重（按名称小写去重，保留第一个）
    seen = set()
    unique_skills = []
    for s in skills:
        key = s["name"].lower().strip("#.")
        if key not in seen:
            seen.add(key)
            unique_skills.append(s)

    return unique_skills


def detect_tech_domains(text: str) -> list[dict]:
    """检测简历涉及的技术领域。"""
    domain_hits = {name: [] for name in TECH_DOMAIN_KEYWORDS}

    for domain, keywords in TECH_DOMAIN_KEYWORDS.items():
        for kw in keywords:
            if kw.lower() in text.lower():
                domain_hits[domain].append(kw)

    result = []
    for domain, hits in domain_hits.items():
        if len(hits) >= 1:
            # 按命中数量 + 关键词长度综合打分
            score = len(hits) + sum(len(k) for k in hits) * 0.1
            result.append({
                "domain": domain,
                "keywords": hits,
                "score": round(score, 1),
            })

    result.sort(key=lambda x: x["score"], reverse=True)
    return result


def parse_projects(text: str) -> list[dict]:
    """解析项目经历。"""
    projects = []
    lines = text.splitlines()
    in_project_section = False
    current_project = None
    project_pattern = re.compile(r'(\d+)[.、．]\s*(.+)')

    for line in lines:
        stripped = line.strip()
        if not stripped:
            continue

        # 检测项目区域
        if re.search(r'项目经验|项目经历|项目', stripped) and len(stripped) < 20:
            in_project_section = True
            continue

        if not in_project_section:
            continue

        # 离开项目区域
        if any(kw in stripped for kw in ["教育", "工作经历", "技能", "证书", "自我评价"]) \
                and len(stripped) < 15:
            break

        # 检测新项目
        m = project_pattern.match(stripped)
        if m:
            if current_project:
                projects.append(current_project)
            current_project = {
                "name": m.group(2).strip(),
                "tech_stack": [],
                "description_lines": [],
            }
            continue

        # 属于当前项目的描述
        if current_project:
            # 提取技术栈
            tech_matches = re.findall(
                r'[A-Z][a-zA-Z+#.\-]*(?:\s*/\s*[A-Z][a-zA-Z+#.\-]*)*', stripped
            )
            for t in tech_matches:
                t = t.strip("/ ")
                if len(t) >= 2:
                    current_project["tech_stack"].append(t)
            current_project["description_lines"].append(stripped)

    # 最后一个项目
    if current_project:
        projects.append(current_project)

    return projects


def parse_education(text: str) -> dict:
    """解析教育背景。"""
    edu = {"school": None, "major": None, "degree": None, "year": None}

    # 提取学位
    for d in ["博士", "硕士", "本科", "专科"]:
        if d in text:
            edu["degree"] = d
            break

    # 提取学校（常见高校关键词）
    school_pattern = r'([^\s，。,\.]{2,}(?:大学|学院|学校))'
    schools = re.findall(school_pattern, text)
    if schools:
        edu["school"] = schools[0]

    # 提取专业
    major_pattern = r'(?:专业|研究方向)[：:]\s*([^\s，。,\.]{2,})'
    m = re.search(major_pattern, text)
    if m:
        edu["major"] = m.group(1).strip()

    # 提取毕业年份
    year_pattern = r'(20\d{2})[年.\s]*(?:毕业|入学|9\d|0\d)'
    years = re.findall(year_pattern, text)
    if years:
        edu["year"] = max(years)  # 取最晚的年份

    return edu


def parse_resume(text: str) -> dict:
    """完整的简历解析入口。"""
    # 清理文本
    text = text.strip()
    if not text:
        return {"error": "简历内容为空"}

    return {
        "level_info": detect_experience_level(text),
        "education": parse_education(text),
        "skills": extract_skills(text),
        "domains": detect_tech_domains(text),
        "projects": parse_projects(text),
        "raw_length": len(text),
    }


# ══════════════════════════════════════════════════════════════════════════
#  面试题生成
# ══════════════════════════════════════════════════════════════════════════

def make_tech_questions(parsed: dict) -> list[dict]:
    """根据技术栈生成技术/专业面试题。"""
    questions = []
    domains = [d["domain"] for d in parsed.get("domains", [])]
    projects = parsed.get("projects", [])
    level = parsed.get("level_info", {}).get("level", "mid")
    skills = parsed.get("skills", [])

    # 按领域生成题目模板
    domain_templates = {
        "大模型": [
            {
                "template": "你在简历中提到了大模型相关经验，请讲讲你对 {tech} 的理解，"
                            "以及它在实际项目中的落地难点和解决方案。",
                "keywords": ["Transformer", "attention"],
                "topic": "大模型基础原理",
                "difficulty": "mid",
            },
            {
                "template": "在实际项目中，你是如何评估和选择不同大模型（如 DeepSeek、Qwen、通义千问、文心一言 等）的？"
                            "请从性能、成本、延迟、可控性等角度分析。",
                "topic": "大模型选型评估",
                "difficulty": "mid",
            },
            {
                "template": "请详细讲讲你对大模型幻觉（Hallucination）问题的理解，"
                            "在你的项目中采用了哪些策略来缓解幻觉？效果如何？",
                "topic": "大模型幻觉缓解",
                "difficulty": "mid",
            },
        ],
        "Agent": [
            {
                "template": "你在简历中提到了 {project} 项目，请详细描述 Multi-Agent 的架构设计——"
                            "各个 Agent 的角色定义、通信机制、任务编排和异常处理是如何设计的？",
                "topic": "Multi-Agent 架构",
                "difficulty": "senior",
            },
            {
                "template": "在设计 Agent 系统时，你是如何保证 Agent 行为的安全性和可控性的？"
                            "如果 Agent 执行了非预期的操作，你的回滚和容错机制是怎样的？",
                "topic": "Agent 安全与容错",
                "difficulty": "senior",
            },
        ],
        "RAG": [
            {
                "template": "请讲讲你的 RAG 系统架构设计。在处理大规模文档时，"
                            "你如何解决检索精度、响应延迟和上下文窗口限制之间的 trade-off？",
                "topic": "RAG 系统架构",
                "difficulty": "mid",
            },
            {
                "template": "你在 RAG 系统中使用了 Semantic Chunking 和 Hybrid Search，"
                            "请讲讲 Semantic Chunking 的实现原理，以及你如何确定最优的 chunk 大小和策略？",
                "topic": "RAG 分块与检索",
                "difficulty": "mid",
            },
        ],
        "NLP": [
            {
                "template": "请解释 {tech} 的原理，以及在你的项目中你是如何进行模型选型和效果评估的？",
                "topic": "NLP 模型原理",
                "difficulty": "mid",
            },
        ],
        "MLOps": [
            {
                "template": "你在简历中提到了模型推理优化相关经验，请具体讲讲 "
                            "vLLM/SGLang 的推理优化原理（PagedAttention、Continuous Batching 等），"
                            "你如何针对业务场景进行调优？",
                "topic": "模型推理优化",
                "difficulty": "senior",
            },
        ],
        "大数据": [
            {
                "template": "你在简历中提到了 {tech}，请结合你的实际项目经验，"
                            "谈谈在处理大规模数据时的性能优化策略和踩过的坑。",
                "topic": "大数据处理",
                "difficulty": "mid",
            },
        ],
        "后端开发": [
            {
                "template": "请讲讲你的项目架构设计：为什么选择 {tech} 技术栈？"
                            "在高并发场景下做了哪些优化？",
                "topic": "系统架构设计",
                "difficulty": "mid",
            },
        ],
    }

    # 从技能中提取最高频的技术名
    top_techs = [s["name"] for s in skills[:10]]

    # 按领域匹配模板
    for domain in domains:
        templates = domain_templates.get(domain, [])
        for tmpl in templates:
            if len(questions) >= 7:
                break

            # 判断难度与候选人级别匹配
            diff = tmpl.get("difficulty", "mid")
            if level == "junior" and diff == "senior":
                continue
            if level == "senior" and diff == "junior":
                continue

            question_text = tmpl["template"]

            # 填充 {tech} 占位符
            if "{tech}" in question_text:
                domain_keywords = None
                for d in parsed.get("domains", []):
                    if d["domain"] == domain:
                        domain_keywords = d["keywords"]
                        break
                tech_fill = (domain_keywords[0] if domain_keywords
                             else (top_techs[0] if top_techs else domain))
                question_text = question_text.replace("{tech}", tech_fill)

            # 填充 {project} 占位符
            if "{project}" in question_text:
                project_name = projects[0]["name"] if projects else "相关"
                question_text = question_text.replace("{project}", project_name)

            # 去重
            if not any(q["question"][:20] == question_text[:20] for q in questions):
                questions.append({
                    "type": "tech",
                    "question": question_text,
                    "topic": tmpl.get("topic", domain),
                    "difficulty": diff,
                    "hint": None,
                })

    # 补充项目深挖题
    for proj in projects[:3]:
        if len(questions) >= 8:
            break
        tech_str = "/".join(proj["tech_stack"][:5]) if proj["tech_stack"] else "相关技术"
        questions.append({
            "type": "tech",
            "question": f"在你的项目「{proj['name']}」中，你提到使用了 {tech_str}。"
                        f"请谈谈项目中最有挑战的技术难点是什么？你是如何分析和解决的？"
                        f"如果重新做一次，你会做哪些不同的选择？",
            "topic": "项目深度挖掘",
            "difficulty": "mid" if level in ("junior", "mid") else "senior",
            "hint": "按照 STAR 原则（情境→任务→行动→结果）组织回答，突出个人贡献和技术深度",
        })

    return questions


def make_behavioral_questions(parsed: dict) -> list[dict]:
    """根据工作/项目经历生成行为面试题。"""
    questions = []
    level = parsed.get("level_info", {}).get("level", "mid")
    projects = parsed.get("projects", [])
    is_senior = parsed.get("level_info", {}).get("is_senior", False)

    templates = [
        {
            "template": "请描述一个你在项目中遇到的技术方案分歧或团队意见冲突的场景。"
                        "你是如何推动达成共识的？",
            "topic": "团队协作与冲突处理",
            "applicable": "all",
        },
        {
            "template": "分享一个你需要在极短时间内交付重要需求的经历。"
                        "你是如何做优先级管理和时间规划的？最终结果如何？",
            "topic": "压力管理与执行力",
            "applicable": "all",
        },
        {
            "template": "你过去做过的最有技术难度或最有成就感的决策是什么？"
                        "这个决策带来了什么影响？",
            "topic": "技术决策力",
            "applicable": "all",
        },
        {
            "template": "如果让你带一个新人或指导初级工程师完成一个复杂需求，"
                        "你会怎么做？请举例说明你的指导方式。",
            "topic": "领导力与 mentoring",
            "applicable": "mid",
        },
        {
            "template": ('请谈谈你对技术债务的理解。在你的实际工作中，'
                         '你是如何平衡「快速交付」和「代码质量」的？'),
            "topic": "工程素养",
            "applicable": "mid",
        },
    ]

    # 高级候选人额外增加管理向问题
    if is_senior:
        templates.extend([
            {
                "template": "作为资深工程师，你是如何做技术规划和技术选型的？"
                            "请分享一个你做过的重大技术选型决策及后续效果。",
                "topic": "技术规划与选型",
                "applicable": "senior",
            },
            {
                "template": "请分享一次你推动跨团队协作或技术基建的经历。"
                            "在推动过程中遇到了哪些阻力，你是如何化解的？",
                "topic": "跨团队影响力",
                "applicable": "senior",
            },
        ])

    for tmpl in templates:
        if len(questions) >= 3:
            break
        # 判断适用性
        if tmpl["applicable"] == "senior" and level in ("junior", "mid"):
            continue
        if tmpl["applicable"] == "mid" and level == "junior":
            continue

        question_text = tmpl["template"]

        # 如果有项目名，嵌入到问题中
        if "{project}" in question_text and projects:
            question_text = question_text.replace(
                "{project}", projects[0]["name"]
            )

        questions.append({
            "type": "behavior",
            "question": question_text,
            "topic": tmpl["topic"],
            "difficulty": "mid" if not is_senior else "senior",
            "hint": "建议使用 STAR 原则组织回答：先说背景 Situation，再说任务 Task，"
                    "重点讲你采取的行动 Action，最后说结果 Result",
        })

    return questions


def make_open_questions(parsed: dict) -> list[dict]:
    """根据简历方向生成开放/思维题。"""
    questions = []
    domains = [d["domain"] for d in parsed.get("domains", [])]
    level = parsed.get("level_info", {}).get("level", "mid")
    is_senior = parsed.get("level_info", {}).get("is_senior", False)

    # 按方向出开放题
    if "大模型" in domains or "Agent" in domains or "RAG" in domains:
        questions.append({
            "type": "open",
            "question": "你认为当前大模型应用落地面临的最大瓶颈是什么？"
                        "如果让你设计下一代 AI 应用架构，你的核心思路是什么？",
            "topic": "AI 行业认知与技术视野",
            "difficulty": "senior" if is_senior else "mid",
            "hint": "结合自己的实践经验，从技术、成本、用户体验等角度综合分析，"
                    "提出有见地的观点而非泛泛而谈",
        })
        questions.append({
            "type": "open",
            "question": "如果让你评估一个 AI 项目的技术可行性，你会从哪些维度进行分析？"
                        "请以一个你熟悉的场景为例。",
            "topic": "AI 项目评估方法论",
            "difficulty": "mid",
            "hint": "从数据可行性、技术可行性、工程复杂度、ROI、风险等维度展开",
        })

    if "大数据" in domains or "后端开发" in domains:
        questions.append({
            "type": "open",
            "question": "设计一个高并发、高可用的系统时，你会考虑哪些关键设计要素？"
                        "请以你熟悉的业务场景为例画出架构草图并说明。",
            "topic": "系统设计思维",
            "difficulty": "senior",
            "hint": "从分层架构、解耦、容错、可扩展性、监控告警等角度展开",
        })

    if "数据分析" in domains or "推荐系统" in domains:
        questions.append({
            "type": "open",
            "question": "如果业务指标出现异常波动（如用户留存率下降），"
                        "你的排查和分析思路是什么？",
            "topic": "数据分析思维",
            "difficulty": "mid",
            "hint": "从指标异动定位→假设验证→归因分析→行动建议的完整链路展开",
        })

    # 兜底：通用开放题
    if not questions:
        questions.append({
            "type": "open",
            "question": "请谈谈你对所在领域未来 1-2 年技术发展趋势的看法，"
                        "以及你打算如何保持技术竞争力？",
            "topic": "技术视野与学习能力",
            "difficulty": "mid",
            "hint": "结合行业趋势和自身职业规划，展示对技术的热情和前瞻性思考",
        })

    return questions


def generate_questions(parsed: dict, count: int = 8,
                       question_type: str = "all",
                       target_role: str = None,
                       ai_role_info: dict = None) -> list[dict]:
    """主入口：生成面试题列表。"""
    questions = []

    # 0. 如果指定了 AI 岗位，优先添加岗位特定题目
    if ai_role_info:
        ai_templates = get_role_specific_templates(ai_role_info)
        for t in ai_templates:
            questions.append({
                "type": "tech",
                "question": t["template"],
                "topic": t["topic"],
                "difficulty": t.get("difficulty", "mid"),
                "hint": None,
                "role_context": ai_role_info["name"],
            })

    # 1. 技术题（约占 50%）
    if question_type in ("all", "tech"):
        tech_qs = make_tech_questions(parsed)
        tech_count = max(3, count * 5 // 10)  # 50%
        questions.extend(tech_qs[:tech_count])

    # 2. 行为题（约占 25%）
    if question_type in ("all", "behavior"):
        beh_qs = make_behavioral_questions(parsed)
        beh_count = max(1, count * 25 // 100)
        questions.extend(beh_qs[:beh_count])

    # 3. 开放题（约占 25%）
    if question_type in ("all", "open"):
        open_qs = make_open_questions(parsed)
        open_count = max(1, count * 25 // 100)
        questions.extend(open_qs[:open_count])

    # 如果用户指定了目标岗位，在题目中标注
    if target_role:
        for q in questions:
            if "role_context" not in q:
                q["role_context"] = target_role

    # 裁剪到目标数量
    if len(questions) > count:
        questions = questions[:count]

    return questions


# ══════════════════════════════════════════════════════════════════════════
#  输出格式化
# ══════════════════════════════════════════════════════════════════════════

def format_markdown(parsed: dict, questions: list[dict],
                    target_role: str = None,
                    ai_role_info: dict = None) -> str:
    """格式化为 Markdown 输出。"""
    level = parsed.get("level_info", {}).get("level", "unknown")
    level_map = {
        "junior": "初级（0-1年）",
        "mid": "中级（2-3年）",
        "mid-senior": "中高级（3-5年）",
        "senior": "高级（5年+）",
    }
    level_label = level_map.get(level, f"未知（{level}）")

    # 按类型分组
    by_type = {}
    for q in questions:
        by_type.setdefault(q["type"], []).append(q)

    lines = []
    lines.append("=" * 80)
    lines.append("                    面试题生成报告")
    if target_role:
        lines.append(f"                    目标岗位：{target_role}")
    if ai_role_info:
        lines.append(f"                    AI 岗位：{ai_role_info['name']}")
    lines.append("=" * 80)
    lines.append("")

    # 候选人概况
    lines.append("## 候选人画像")
    lines.append("")
    lines.append(f"- **检测级别**：{level_label}")
    lines.append(f"- **技术领域**：{'、'.join(d['domain'] for d in parsed.get('domains', [])[:5])}")
    projects = parsed.get("projects", [])
    if projects:
        lines.append(f"- **项目经验**：{len(projects)} 个项目")
        for p in projects[:3]:
            lines.append(f"  - {p['name']}")
    edu = parsed.get("education", {})
    if edu.get("school"):
        lines.append(f"- **教育背景**：{edu.get('school', '')} {edu.get('degree', '')} {edu.get('major', '')}")
    lines.append("")

    # 题目
    type_labels = {
        "tech": "技术/专业题",
        "behavior": "行为/软技能题",
        "open": "开放/思维题",
    }
    type_icons = {"tech": "💻", "behavior": "🤝", "open": "🧠"}
    diff_labels = {"junior": "初级", "mid": "中级", "senior": "高级"}

    for qtype in ["tech", "behavior", "open"]:
        qlist = by_type.get(qtype, [])
        if not qlist:
            continue

        icon = type_icons.get(qtype, "")
        label = type_labels.get(qtype, qtype)
        lines.append(f"--- {icon} {label} ---")
        lines.append("")

        for i, q in enumerate(qlist, 1):
            diff = diff_labels.get(q.get("difficulty", "mid"), "中级")
            lines.append(f"### {i}. {q['question']}")
            lines.append("")
            lines.append(f"- **考察点**：{q.get('topic', '通用能力')}")
            lines.append(f"- **难度**：{diff}")
            if q.get("hint"):
                lines.append(f"- **推荐思路**：{q['hint']}")
            lines.append("")

    lines.append("=" * 80)
    return "\n".join(lines)


def format_json(parsed: dict, questions: list[dict],
                target_role: str = None) -> str:
    """格式化为 JSON 输出。"""
    output = {
        "candidate_profile": {
            "level": parsed.get("level_info", {}).get("level"),
            "years_experience": parsed.get("level_info", {}).get("years"),
            "domains": [d["domain"] for d in parsed.get("domains", [])[:5]],
            "education": parsed.get("education"),
            "project_count": len(parsed.get("projects", [])),
        },
        "target_role": target_role,
        "questions": [
            {
                "type": q["type"],
                "difficulty": q.get("difficulty", "mid"),
                "question": q["question"],
                "topic": q.get("topic"),
                "hint": q.get("hint"),
            }
            for q in questions
        ],
        "total": len(questions),
    }
    return json.dumps(output, ensure_ascii=False, indent=2)


# ══════════════════════════════════════════════════════════════════════════
#  AI 岗位参考加载
# ══════════════════════════════════════════════════════════════════════════

def load_ai_job_role(role_name: str) -> dict | None:
    """加载 AI 岗位参考文件，返回岗位能力模型的摘要信息。"""
    md_path = AI_JOB_ROLES.get(role_name)
    if not md_path or not md_path.exists():
        available = ", ".join(AI_JOB_ROLES.keys())
        print(f"⚠️  未找到 AI 岗位「{role_name}」，可用岗位: {available}", file=sys.stderr)
        return None

    with open(md_path, "r", encoding="utf-8") as f:
        content = f.read()

    # 提取岗位定位
    pos_match = re.search(r"\*\*定位\*\*[：:](.*?)(?:\n\n|\n###|\n---)", content, re.DOTALL)
    positioning = pos_match.group(1).strip() if pos_match else ""

    # 提取总体要求
    overview_match = re.search(r"\*\*总体要求\*\*[：:](.*?)(?:\n\n|\n---)", content, re.DOTALL)
    overview_req = overview_match.group(1).strip() if overview_match else ""

    # 提取工具链（核心技术栈）
    tools = []
    tool_table_match = re.search(r"\|.*\|.*\|.*\|\n\|.*\|.*\|.*\|\n(.*?)(?:\n\n|\n###)", content, re.DOTALL)
    if tool_table_match:
        for line in tool_table_match.group(1).strip().split("\n"):
            parts = [p.strip() for p in line.split("|") if p.strip()]
            if len(parts) >= 2:
                tools.append(parts[1] if len(parts) >= 2 else parts[0])

    # 提取各层级画像
    profiles = {}
    profile_section = re.search(r"三个层级的岗位画像速览.*?(?=\n###|\Z)", content, re.DOTALL)
    if profile_section:
        rows = profile_section.group(0).split("\n")
        for row in rows:
            if "L" in row and "|" in row:
                parts = [p.strip() for p in row.split("|") if p.strip()]
                for i, part in enumerate(parts):
                    if "L" in part and i + 1 < len(parts):
                        profiles[part.strip()] = parts[i + 1][:100]

    return {
        "name": role_name,
        "positioning": positioning,
        "overview": overview_req[:300] if overview_req else "",
        "核心技术栈": tools[:10],
        "层级画像": profiles,
    }


def list_ai_roles() -> list[str]:
    """列出所有可用的 AI 岗位。"""
    return sorted(AI_JOB_ROLES.keys())


def get_role_specific_templates(ai_role_info: dict | None) -> list[dict]:
    """根据 AI 岗位信息获取特定面试题模板。"""
    if not ai_role_info:
        return []

    templates = {
        "AI研发工程师": [
            {
                "template": "作为 AI 研发工程师，你如何平衡算法创新和工程稳定性？请结合项目经验谈谈你的实践。",
                "topic": "AI 工程化思维",
                "difficulty": "mid",
            },
            {
                "template": "请描述一个你从 0 到 1 构建 AI 应用的完整流程，"
                            "从需求分析、数据准备、模型选型到部署上线的全链路中，你认为最关键的环节是什么？",
                "topic": "AI 全链路开发能力",
                "difficulty": "mid",
            },
        ],
        "AI数据治理工程师": [
            {
                "template": "作为 AI 数据治理工程师，你是如何确保数据质量满足 AI 模型训练要求的？"
                            "请描述你的数据质量评估体系。",
                "topic": "数据质量管理",
                "difficulty": "mid",
            },
            {
                "template": "请谈谈你在「垃圾进，垃圾出」原则下的实践经验——"
                            "你是如何发现并修复低质量数据对 AI 模型影响的？",
                "topic": "数据治理实践",
                "difficulty": "mid",
            },
        ],
        "AI测试工程师": [
            {
                "template": "作为 AI 测试工程师，测传统系统和测 AI 系统最大的不同是什么？"
                            "你如何评估大模型输出的正确性？",
                "topic": "AI 质量保障",
                "difficulty": "mid",
            },
            {
                "template": "请设计一个大模型的评测方案——你会从哪些维度进行评测？"
                            "如何设计和维护评测集？",
                "topic": "大模型评测体系",
                "difficulty": "senior",
            },
        ],
        "AI安全工程师": [
            {
                "template": "作为 AI 安全工程师，你如何理解 OWASP Top 10 for LLM？"
                            "请举例说明你在实际项目中遇到过或防范过的 AI 安全风险。",
                "topic": "AI 安全威胁认知",
                "difficulty": "mid",
            },
            {
                "template": "请设计一个 AI 系统的多层防御体系——"
                            "从输入过滤、模型防护到输出审核，你会如何分层设计？",
                "topic": "AI 安全架构",
                "difficulty": "senior",
            },
        ],
        "AI产品经理": [
            {
                "template": "作为 AI 产品经理，你如何评估一个 AI 功能是否值得落地？"
                            "从技术可行性、用户价值和商业回报三个维度展开。",
                "topic": "AI 产品价值评估",
                "difficulty": "mid",
            },
            {
                "template": "AI 产品与传统产品的核心差异是什么？"
                            "你如何管理 AI 产品特有的不确定性（如模型效果不可预测、幻觉风险）？",
                "topic": "AI 产品思维",
                "difficulty": "mid",
            },
        ],
    }

    return templates.get(ai_role_info["name"], [])


# ══════════════════════════════════════════════════════════════════════════
#  CLI
# ══════════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(
        description="面试题生成工具 — 从简历抽取内容并生成针对性面试题",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )

    input_group = parser.add_mutually_exclusive_group()
    input_group.add_argument("--input", "-i", metavar="FILE",
                             help="简历文件路径（.pdf / .docx / .txt）")
    input_group.add_argument("--text", "-t", metavar="TEXT",
                             help="直接输入简历文本内容")

    parser.add_argument("--output", "-o", metavar="FILE",
                        help="输出文件路径（不指定则输出到 stdout）")
    parser.add_argument("--format", "-f", choices=["markdown", "json"],
                        default="markdown", help="输出格式（默认 markdown）")
    parser.add_argument("--count", "-c", type=int, default=8,
                        help="生成的面试题总数（默认 8）")
    parser.add_argument("--role", "-r", metavar="ROLE",
                        help="目标岗位名称（如：NLP算法工程师）")
    parser.add_argument("--level", "-l", choices=["junior", "mid", "senior"],
                        help="手动指定候选人级别（覆盖自动检测）")
    parser.add_argument("--type", "-T", choices=["all", "tech", "behavior", "open"],
                        default="all", help="题目类型过滤（默认 all）")
    parser.add_argument("--dry-run", "-d", action="store_true",
                        help="只解析简历并展示结构化数据，不生成题目")
    parser.add_argument("--ai-role", metavar="ROLE",
                        choices=sorted(AI_JOB_ROLES.keys()),
                        help="AI 岗位名称，加载对应岗位能力模型（ai-jobs/）生成针对性题目")
    parser.add_argument("--list-ai-roles", action="store_true",
                        help="列出所有可用的 AI 岗位后退出")
    parser.add_argument("--list-llm-topics", action="store_true",
                        help="列出所有可用的 LLM 通用面试题主题后退出")
    parser.add_argument("--llm-topic", metavar="TOPIC",
                        help="LLM 通用面试题主题（如：RAG、Agent、大模型原理 等），加载对应参考题集")

    args = parser.parse_args()

    # 列出 AI 岗位
    if args.list_ai_roles:
        print("可用的 AI 岗位参考:")
        for name in list_ai_roles():
            path = AI_JOB_ROLES[name]
            size = path.stat().st_size if path.exists() else 0
            print(f"  - {name}  ({size/1024:.0f} KB)")
        return

    # 列出 LLM 通用面试题主题
    if args.list_llm_topics:
        print("可用的 LLM 通用面试题主题:")
        for topic, path in LLM_TOPICS.items():
            size = path.stat().st_size if path.exists() else 0
            print(f"  - {topic}  ({size/1024:.0f} KB)")
        return

    # 获取简历文本
    resume_text = None
    if args.text:
        resume_text = args.text.strip()
    elif args.input:
        print(f"📄 正在提取: {args.input}", file=sys.stderr)
        try:
            resume_text = extract_text_from_file(args.input)
        except Exception as e:
            print(f"❌ 提取失败: {e}", file=sys.stderr)
            sys.exit(1)
    else:
        # 尝试从 stdin 读取
        if not sys.stdin.isatty():
            resume_text = sys.stdin.read().strip()
        else:
            parser.print_help()
            print("\n错误: 请指定 --input、--text 或通过管道传入简历内容", file=sys.stderr)
            sys.exit(1)

    if not resume_text:
        print("❌ 简历内容为空", file=sys.stderr)
        sys.exit(1)

    # 解析简历
    print("🔍 正在分析简历...", file=sys.stderr)
    parsed = parse_resume(resume_text)
    char_count = len(resume_text)
    print(f"✅ 简历解析完成：{char_count} 字符，"
          f"检测到 {len(parsed.get('domains', []))} 个技术领域，"
          f"{len(parsed.get('projects', []))} 个项目",
          file=sys.stderr)

    # 覆盖级别
    if args.level:
        parsed["level_info"]["level"] = args.level

    level_info = parsed.get("level_info", {})
    level_str = level_info.get("level", "unknown")
    years_str = ""
    if level_info.get("years"):
        years_str = f" ({level_info['years']}年经验)"
    print(f"📊 候选人级别: {level_str}{years_str}",
          file=sys.stderr)

    if args.dry_run:
        print("\n" + "=" * 60, file=sys.stderr)
        print("📋 简历结构化数据（--dry-run）", file=sys.stderr)
        print("=" * 60, file=sys.stderr)
        dry = {
            "level_info": level_info,
            "education": parsed.get("education"),
            "domains": [d["domain"] for d in parsed.get("domains", [])],
            "skills_count": len(parsed.get("skills", [])),
            "projects": [
                {"name": p["name"], "tech_stack": p["tech_stack"]}
                for p in parsed.get("projects", [])
            ],
        }
        print(json.dumps(dry, ensure_ascii=False, indent=2))
        return

    # 加载 AI 岗位参考
    ai_role_info = None
    if args.ai_role:
        print(f"📚 加载 AI 岗位参考: {args.ai_role}", file=sys.stderr)
        ai_role_info = load_ai_job_role(args.ai_role)

    # 加载 LLM 通用面试题主题参考
    llm_topic_file = None
    llm_topic_name = None
    if args.llm_topic:
        llm_topic_name = args.llm_topic
        if llm_topic_name in LLM_TOPICS:
            llm_topic_file = LLM_TOPICS[llm_topic_name]
            print(f"📚 加载 LLM 通用面试题参考: {llm_topic_name}", file=sys.stderr)
        else:
            print(f"⚠️  未知的 LLM 主题: {llm_topic_name}，可用主题: {', '.join(LLM_TOPICS.keys())}", file=sys.stderr)

    # 生成面试题
    role_label = f"（目标岗位: {args.role}）" if args.role else ""
    ai_label = f"（AI 岗位: {args.ai_role}）" if args.ai_role else ""
    print(f"🎯 正在生成 {args.count} 道面试题{role_label}{ai_label}...",
          file=sys.stderr)
    questions = generate_questions(
        parsed,
        count=args.count,
        question_type=args.type,
        target_role=args.role or args.ai_role,
        ai_role_info=ai_role_info,
    )

    # 统计
    type_count = {}
    for q in questions:
        type_count[q["type"]] = type_count.get(q["type"], 0) + 1
    print(f"✅ 生成完成: " + ", ".join(f"{k}={v}" for k, v in type_count.items()),
          file=sys.stderr)

    # 输出
    if args.format == "json":
        output = format_json(parsed, questions, args.role or args.ai_role)
    else:
        output = format_markdown(parsed, questions, args.role or args.ai_role, ai_role_info)

    if args.output:
        os.makedirs(os.path.dirname(os.path.abspath(args.output)) or ".", exist_ok=True)
        with open(args.output, "w", encoding="utf-8") as f:
            f.write(output)
        print(f"💾 已保存到: {args.output}", file=sys.stderr)
    else:
        sys.stdout.write(output)
        sys.stdout.write("\n")


if __name__ == "__main__":
    main()
